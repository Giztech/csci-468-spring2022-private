package edu.montana.csci.csci468.demo;

public class BytecodeDemo {

    int add(int i) {
        return i + 13;
    }

}
